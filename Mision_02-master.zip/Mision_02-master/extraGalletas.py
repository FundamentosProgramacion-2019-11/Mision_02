#Aline Paulette Villegas Berdejo, A01375818
#Calcular cuanta cantidad de ingredientes se necesitan para hacer galletas


g=int(input("Galletas a elaborar:"))
ta=g*(1.5/48)
tm=g*(1/48)
th=g*(2.75/48)

print("Tazas de azúcar: %.2f " % ta)
print("Tazas de mantequilla: %.2f" % tm)
print("Tazas de harina: %.2f" % th)
