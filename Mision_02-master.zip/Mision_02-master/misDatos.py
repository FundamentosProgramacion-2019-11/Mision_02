# Autor: Aline Paulette Villegas Berdejo, A01375818
# Descripción: Imprimir mis datos personales

# Escribe tu programa después de esta línea.
print("Nombre: ")
print("Aline Paulette Villegas Berdejo")
print("Matrícula: ")
print("A01375818")
print("Carrera: ")
print("LCMD")
print("Escuela de procedencia: ")
print("Prepa Tec, programa multicultural: ")
print("Descripción: ")
print("Me gusta leer sobre ensayos sociológicos y me considero buena analizando temas relacionados con el estudio de la sociedad.")
print("Practico gimnasio y veo películas en mis ratos libres.")