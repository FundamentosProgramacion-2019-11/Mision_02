# Misión 02

## Algoritmos y programas

Primero, descarga el archivo con el botón verde de la derecha (**Clone or download**), selecciona **Download ZIP** y guárdalo en una carpeta especial para esta tarea.

Consulta el documento **Mision_02.docx** para ver los detalles.

Si cumples esta misión, podrás **ganar** hasta **1250 puntos de HP**.

Las **primeras 10 personas** que completen esta misión obtendrán **100 XP**.

***

### ¿Y para qué sirven los XP que estoy ganando?

Entre otras cosas:

- Por 200 XP podrás preguntar al profesor si tu respuesta a una pregunta del examen teórico es correcta.

- Por 300 XP podrás preguntar al profesor la respuesta correcta de una pregunta del examen teórico.

- Por 100 XP podrás pedir al profesor que descarte la mitad de las opciones en una pregunta del examen teórico.
