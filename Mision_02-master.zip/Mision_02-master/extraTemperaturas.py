#Autor: Aline Paulette Villegas Berdejo, A01375818
#Descripción: Calcular la temperatura de escala Fahrenheit a Celsius


f=int(input("Temperatura en escala Fahrenheit: "))
c=((f-32)*5)/9
print("Temperatura en escala Celsius: %.1f " % c, "°")
